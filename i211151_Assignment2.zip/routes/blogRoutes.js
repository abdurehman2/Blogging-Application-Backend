const express = require("express");
const User = require("../models/user");
const jwt = require("jsonwebtoken");
const router = express.Router();

// router.get();

// router.post();

// router.put();

// router.delete();

module.exports = router;
